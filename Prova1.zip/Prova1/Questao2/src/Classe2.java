public class Classe2 extends Classe1{
    public void f(){
        System.out.println(" 2 ");
    }
}