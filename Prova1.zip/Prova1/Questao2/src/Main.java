public class Main {
    public static void main(String[] args) {
        Classe1 a = new Classe1();
        a.f();
        Classe2 b = new Classe2();
        b.f();
        a = b;
        a.f();
        b.g();
    }
}
