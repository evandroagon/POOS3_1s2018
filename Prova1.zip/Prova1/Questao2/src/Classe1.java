public class Classe1 {
    public void f(){
        System.out.println(" 1 ");
    }

    public void g(){
        f();
    }
}

